﻿using System;

namespace AfterMonth
{
    public class Program
    {
        static void Main(string[] args)
        {
            Run run = new Run();
            run.Execute();
        }
    }
}